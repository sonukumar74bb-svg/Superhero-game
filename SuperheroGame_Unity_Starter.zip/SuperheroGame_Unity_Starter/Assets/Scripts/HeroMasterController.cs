using System.Collections.Generic;
using UnityEngine;

namespace HeroGame.Core
{
    [RequireComponent(typeof(CharacterController))]
    public class HeroMasterController : MonoBehaviour
    {
        [Header("Movement")]
        public float walkSpeed = 6f;
        public float sprintSpeed = 10f;
        public float jumpHeight = 2f;
        public float gravity = -20f;
        public float turnSmoothTime = 0.1f;

        [Header("Grappling")]
        public LayerMask grappleableMask = ~0;
        public float maxGrappleDistance = 60f;
        public float pullSpeed = 25f;
        public LineRenderer lineRenderer;
        public Transform grappleOrigin;

        [Header("Combat")]
        public float attackDamage = 25f;
        public float attackRange = 3f;
        public LayerMask enemyLayer = ~0;
        public float attackCooldown = 0.5f;

        [Header("References")]
        public Transform cameraTransform;

        [HideInInspector] public Vector2 moveInput;
        [HideInInspector] public Vector2 cameraInput;

        private CharacterController controller;
        private Vector3 velocity;
        private bool isGrounded;
        private bool isGrappling;
        private Vector3 grapplePoint;
        private float turnVelocity;
        private float nextAttackTime;
        private readonly HashSet<EnemyHealth> hitThisAttack =
            new HashSet<EnemyHealth>();

        public bool IsGrappling => isGrappling;
        public bool IsGrounded => isGrounded;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();

            if (cameraTransform == null && Camera.main != null)
                cameraTransform = Camera.main.transform;

            if (lineRenderer == null)
                lineRenderer = GetComponent<LineRenderer>();

            if (lineRenderer == null)
                lineRenderer = gameObject.AddComponent<LineRenderer>();

            lineRenderer.useWorldSpace = true;
            lineRenderer.positionCount = 0;
            lineRenderer.startWidth = 0.04f;
            lineRenderer.endWidth = 0.02f;
        }

        private void Update()
        {
            isGrounded = controller.isGrounded;

            if (isGrounded && velocity.y < 0f)
                velocity.y = -2f;

            if (isGrappling)
                UpdateGrapple();
            else
                UpdateMovement();

            velocity.y += gravity * Time.deltaTime;
            controller.Move(velocity * Time.deltaTime);
        }

        private void UpdateMovement()
        {
            Vector3 input = new Vector3(moveInput.x, 0f, moveInput.y);
            input = Vector3.ClampMagnitude(input, 1f);

            if (cameraTransform != null && input.sqrMagnitude > 0.01f)
            {
                float cameraYaw = cameraTransform.eulerAngles.y;
                float targetAngle =
                    Mathf.Atan2(input.x, input.z) * Mathf.Rad2Deg + cameraYaw;

                float angle = Mathf.SmoothDampAngle(
                    transform.eulerAngles.y,
                    targetAngle,
                    ref turnVelocity,
                    turnSmoothTime
                );

                transform.rotation = Quaternion.Euler(0f, angle, 0f);

                Vector3 direction =
                    Quaternion.Euler(0f, targetAngle, 0f) * Vector3.forward;

                float speed = moveInput.magnitude > 0.8f
                    ? sprintSpeed : walkSpeed;

                controller.Move(direction.normalized * speed * Time.deltaTime);
            }
        }

        // Connect a mobile joystick to this method.
        public void SetMoveInput(Vector2 input)
        {
            moveInput = Vector2.ClampMagnitude(input, 1f);
        }

        // Alternative for UI systems that provide two float values.
        public void SetMoveInput(float x, float y)
        {
            SetMoveInput(new Vector2(x, y));
        }

        public void StopMoving()
        {
            moveInput = Vector2.zero;
        }

        // Connect to the Jump button.
        public void Jump()
        {
            if (isGrounded && !isGrappling)
                velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        // Connect to the Grapple button.
        public void ToggleGrapple()
        {
            if (isGrappling)
                StopGrapple();
            else
                StartGrapple();
        }

        private void StartGrapple()
        {
            if (cameraTransform == null)
                return;

            if (Physics.Raycast(
                cameraTransform.position,
                cameraTransform.forward,
                out RaycastHit hit,
                maxGrappleDistance,
                grappleableMask,
                QueryTriggerInteraction.Ignore))
            {
                grapplePoint = hit.point;
                isGrappling = true;
                velocity.y = 0f;
                lineRenderer.positionCount = 2;
                UpdateRope();
            }
        }

        private void UpdateGrapple()
        {
            UpdateRope();

            Vector3 target = grapplePoint - transform.position;
            float distance = target.magnitude;

            if (distance > 2f)
            {
                Vector3 pullDirection = target.normalized;
                controller.Move(pullDirection * pullSpeed * Time.deltaTime);

                Vector3 horizontal =
                    new Vector3(pullDirection.x, 0f, pullDirection.z);

                if (horizontal.sqrMagnitude > 0.01f)
                    transform.rotation = Quaternion.LookRotation(horizontal);
            }
        }

        private void UpdateRope()
        {
            if (lineRenderer == null || !isGrappling)
                return;

            Vector3 origin = grappleOrigin != null
                ? grappleOrigin.position
                : transform.position + Vector3.up;

            lineRenderer.SetPosition(0, origin);
            lineRenderer.SetPosition(1, grapplePoint);
        }

        public void StopGrapple()
        {
            isGrappling = false;

            if (lineRenderer != null)
                lineRenderer.positionCount = 0;
        }

        // Connect to the Attack button.
        public void PerformBasicAttack()
        {
            if (Time.time < nextAttackTime)
                return;

            nextAttackTime = Time.time + attackCooldown;
            hitThisAttack.Clear();

            Vector3 center = transform.position + Vector3.up
                + transform.forward * (attackRange * 0.5f);

            Collider[] hits = Physics.OverlapSphere(
                center,
                attackRange,
                enemyLayer,
                QueryTriggerInteraction.Collide
            );

            foreach (Collider hit in hits)
            {
                EnemyHealth health = hit.GetComponentInParent<EnemyHealth>();

                if (health != null && hitThisAttack.Add(health))
                    health.TakeDamage(attackDamage);
            }
        }

        private void OnDisable()
        {
            isGrappling = false;

            if (lineRenderer != null)
                lineRenderer.positionCount = 0;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(
                transform.position + Vector3.up
                    + transform.forward * (attackRange * 0.5f),
                attackRange
            );
        }
    }
}
