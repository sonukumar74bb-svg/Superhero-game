using UnityEngine;

namespace HeroGame.Core
{
    public class EnemyHealth : MonoBehaviour
    {
        [Header("Health")]
        public float maxHealth = 100f;

        public float CurrentHealth { get; private set; }
        public bool IsDead { get; private set; }

        private void Awake()
        {
            CurrentHealth = Mathf.Max(1f, maxHealth);
        }

        public void TakeDamage(float damage)
        {
            if (IsDead || damage <= 0f)
                return;

            CurrentHealth = Mathf.Max(0f, CurrentHealth - damage);

            Debug.Log(
                $"{gameObject.name}: {CurrentHealth}/{maxHealth} HP"
            );

            if (CurrentHealth <= 0f)
                Die();
        }

        private void Die()
        {
            IsDead = true;
            Debug.Log($"{gameObject.name} was defeated!");
            gameObject.SetActive(false);
        }

        public void ResetHealth()
        {
            IsDead = false;
            CurrentHealth = Mathf.Max(1f, maxHealth);
            gameObject.SetActive(true);
        }
    }
}
