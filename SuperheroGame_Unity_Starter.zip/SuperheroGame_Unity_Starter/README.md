# SuperheroGame Unity Starter

This ZIP contains the two C# scripts prepared in the conversation. It is a **starter project scaffold**, not a complete playable game or a ready-made APK.

## Contents
- `Assets/Scripts/HeroMasterController.cs` — third-person movement, jump, pull-to-anchor grapple, basic attack, and methods intended for UI controls.
- `Assets/Scripts/EnemyHealth.cs` — basic enemy health and defeat logic.
- `Packages/manifest.json` — minimal Unity package manifest.
- `ProjectSettings/ProjectVersion.txt` — Unity editor version placeholder.

## Important limitations
- No scenes, character models, animations, city, missions, mobile joystick prefab, or Android APK are included.
- The scripts have not been compiled or tested in the Unity Editor in this environment.
- The grapple currently pulls the character toward an anchor; it is not a full rope-swing physics system.
- The camera is referenced but this package does not create or configure a third-person camera.
- Enemy damage requires enemy colliders on a layer included in `enemyLayer` and an `EnemyHealth` component on the enemy or a parent.
- Mobile buttons and a joystick still need to be created and connected in Unity.

## Opening in Unity
1. Extract this ZIP on a computer that has Unity Hub and a compatible Unity Editor installed.
2. In Unity Hub, choose **Add/Open project** and select the extracted folder.
3. Wait for Unity to import the project.
4. Create a scene and add a ground plane, a player object, and a camera.
5. Add `CharacterController` and `HeroMasterController` to the player.
6. Add colliders and `EnemyHealth` to test enemies.
7. Connect UI buttons to `Jump`, `ToggleGrapple`, and `PerformBasicAttack`. A joystick should call `SetMoveInput` while held and `StopMoving` when released.
8. Test in the Editor, fix errors, then configure Android Build Support and build an APK.

## Android-only note
This ZIP cannot be compiled into an APK directly on an Android phone by opening the C# files. A compatible Unity build environment is required.
